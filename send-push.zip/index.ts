// Import standard Deno HTTP server handling modules
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
// Using Deno's native npm specifier for the official web-push package
import webpush from "npm:web-push@3.6.7"

const COR_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  console.log("[SEND-PUSH] --- New Request Triggered ---");
  console.log(`[SEND-PUSH] Incoming HTTP Method: ${req.method}`);

  // Handle CORS preflight requests smoothly
  if (req.method === 'OPTIONS') {
    console.log("[SEND-PUSH] OPTIONS request detected. Returning CORS headers.");
    return new Response('ok', { headers: COR_HEADERS })
  }

  try {
    console.log("[SEND-PUSH] Parsing JSON payload from incoming request...");
    const payloadData = await req.json();
    console.log("[SEND-PUSH] Raw Incoming Data:", JSON.stringify(payloadData, null, 2));

    const { subscription, title, body, url } = payloadData;

    console.log("[SEND-PUSH] Validating subscription credentials...");
    // Enforce payload validation constraints
    if (!subscription || !subscription.endpoint) {
      console.error("[SEND-PUSH] ERROR: Subscription payload is missing or lacks an endpoint URL.");
      return new Response(JSON.stringify({ error: "Missing subscription target mapping metadata" }), {
        status: 400,
        headers: { ...COR_HEADERS, "Content-Type": "application/json" }
      })
    }
    console.log(`[SEND-PUSH] Validation passed. Target Endpoint: ${subscription.endpoint}`);

    console.log("[SEND-PUSH] Configuring WebPush with hardcoded VAPID keys...");
    // Hardcoded cryptographic server configuration details
    const VAPID_PUBLIC_KEY = "BAkq_2ZCp335lLLytu54Wsv7RDDhHYgz21DMHQ1Np-6RKR-VcpzxNaJ4HNGUKT25jNf6J_T9s1hh8mUGWTBXax8";
    const VAPID_PRIVATE_KEY = "uUSH6q1V1gDLiHWAiHF-9F9QIi4EGSgW_bG3Eehh53Q";
    
    // Set VAPID details on the native webpush client
    webpush.setVapidDetails(
      "mailto:admin@elor.com",
      VAPID_PUBLIC_KEY,
      VAPID_PRIVATE_KEY
    );
    console.log("[SEND-PUSH] WebPush library successfully initialized.");

    console.log("[SEND-PUSH] Constructing notification payload structure...");
    // Construct the standard structure expected by the service worker push event
    const pushPayload = JSON.stringify({
      title: title || "ELOR Atelier",
      body: body || "You have an update regarding your bespoke order.",
      url: url || "/orders.html"
    })
    console.log(`[SEND-PUSH] Final Push Payload: ${pushPayload}`);

    console.log("[SEND-PUSH] Firing notification to browser network operator...");
    // Fire the push notification using the standard syntax format
    await webpush.sendNotification(subscription, pushPayload);

    console.log("[SEND-PUSH] SUCCESS: Payload successfully accepted by the push service.");
    return new Response(JSON.stringify({ success: true, message: "Push dispatched cleanly to delivery network" }), {
      status: 200,
      headers: { ...COR_HEADERS, "Content-Type": "application/json" }
    })

  } catch (error: any) {
    console.error("[SEND-PUSH] FATAL EXCEPTION caught during processing:");
    console.error(error);
    
    if (error.statusCode) {
        console.error(`[SEND-PUSH] Push Service HTTP Status: ${error.statusCode}`);
        console.error(`[SEND-PUSH] Push Service Rejection Body: ${error.body}`);
    }

    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...COR_HEADERS, "Content-Type": "application/json" }
    })
  }
})
